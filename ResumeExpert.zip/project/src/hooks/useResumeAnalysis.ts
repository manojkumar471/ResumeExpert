import { useCallback } from 'react';
import { useAppContext } from '../context/AppContext';
import { analyzeResume } from '../utils/aiMockServices';

export const useResumeAnalysis = () => {
  const { state, dispatch } = useAppContext();

  const startAnalysis = useCallback(async () => {
    if (!state.resume) return;

    dispatch({ type: 'SET_ANALYZING', payload: true });

    try {
      const result = await analyzeResume(
        state.resume,
        state.jobDescription,
        state.preferences.industry,
        state.preferences.careerLevel
      );
      
      dispatch({ type: 'SET_ANALYSIS_RESULT', payload: result });
    } catch (error) {
      console.error('Analysis failed:', error);
      dispatch({ type: 'SET_ANALYZING', payload: false });
    }
  }, [state.resume, state.jobDescription, state.preferences, dispatch]);

  const clearAnalysis = useCallback(() => {
    dispatch({ type: 'CLEAR_ANALYSIS' });
  }, [dispatch]);

  return {
    startAnalysis,
    clearAnalysis,
    isAnalyzing: state.isAnalyzing,
    analysisResult: state.analysisResult,
  };
};