import React, { useCallback, useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, FileText, X, CheckCircle } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { processFile, validateFile } from '../utils/fileProcessing';

const UploadSection: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const [isDragOver, setIsDragOver] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const handleFileUpload = useCallback(async (file: File) => {
    const error = validateFile(file);
    if (error) {
      setUploadError(error);
      return;
    }

    setIsUploading(true);
    setUploadError(null);

    try {
      const resumeData = await processFile(file);
      dispatch({ type: 'SET_RESUME', payload: resumeData });
    } catch (err) {
      setUploadError('Failed to process file. Please try again.');
    } finally {
      setIsUploading(false);
    }
  }, [dispatch]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  }, [handleFileUpload]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileUpload(files[0]);
    }
  }, [handleFileUpload]);

  const removeResume = () => {
    dispatch({ type: 'SET_RESUME', payload: null });
    dispatch({ type: 'CLEAR_ANALYSIS' });
  };

  if (state.resume) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-400/20 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-400" />
            </div>
            <div>
              <p className="font-medium text-white">{state.resume.filename}</p>
              <p className="text-sm text-slate-400">
                Uploaded {state.resume.uploadedAt.toLocaleTimeString()}
              </p>
            </div>
          </div>
          <motion.button
            onClick={removeResume}
            className="p-2 text-slate-400 hover:text-red-400 transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <X className="h-5 w-5" />
          </motion.button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="text-center">
        <h2 className="text-2xl font-bold text-white mb-2">Upload Your Resume</h2>
        <p className="text-slate-400">
          Get instant AI-powered analysis and personalized feedback
        </p>
      </div>

      <motion.div
        className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all ${
          isDragOver
            ? 'border-cyan-400 bg-cyan-400/10'
            : 'border-slate-600 hover:border-slate-500'
        }`}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
        whileHover={{ scale: 1.02 }}
      >
        <input
          type="file"
          onChange={handleFileSelect}
          accept=".pdf,.docx,.doc,.txt"
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          disabled={isUploading}
        />
        
        <div className="space-y-4">
          {isUploading ? (
            <motion.div
              className="flex flex-col items-center space-y-2"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <div className="p-3 bg-cyan-400/20 rounded-full">
                <Upload className="h-8 w-8 text-cyan-400" />
              </div>
              <p className="text-cyan-400 font-medium">Processing your resume...</p>
            </motion.div>
          ) : (
            <>
              <div className="p-3 bg-slate-700/50 rounded-full w-fit mx-auto">
                <FileText className="h-8 w-8 text-slate-400" />
              </div>
              <div>
                <p className="text-lg font-medium text-white mb-1">
                  Drop your resume here or click to browse
                </p>
                <p className="text-sm text-slate-400">
                  Supports PDF, DOCX, DOC, and TXT files (max 5MB)
                </p>
              </div>
            </>
          )}
        </div>
      </motion.div>

      {uploadError && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-red-400/20 border border-red-400/50 rounded-lg"
        >
          <p className="text-red-400 text-sm">{uploadError}</p>
        </motion.div>
      )}
    </motion.div>
  );
};

export default UploadSection;