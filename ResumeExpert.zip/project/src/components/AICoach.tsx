import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, 
  MessageCircle, 
  Send, 
  User, 
  Sparkles, 
  Target, 
  TrendingUp, 
  Award, 
  BookOpen, 
  Users, 
  Briefcase,
  CheckCircle,
  AlertCircle,
  Clock,
  BarChart3
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { generateAICoachAnalysis, generateCoachResponse } from '../utils/aiMockServices';
import { CoachingSession, ChatMessage } from '../types';

const AICoach: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const [activeSessionType, setActiveSessionType] = useState<'resume-review' | 'career-guidance' | 'interview-prep' | 'skill-assessment'>('resume-review');
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [state.activeCoachingSession]);

  const startCoachAnalysis = async () => {
    if (!state.resume) return;

    dispatch({ type: 'SET_COACH_ANALYZING', payload: true });

    try {
      const analysis = await generateAICoachAnalysis(
        state.resume,
        state.jobDescription,
        state.preferences.industry,
        state.preferences.careerLevel
      );
      
      dispatch({ type: 'SET_COACH_ANALYSIS', payload: analysis });
    } catch (error) {
      console.error('Coach analysis failed:', error);
      dispatch({ type: 'SET_COACH_ANALYZING', payload: false });
    }
  };

  const startCoachingSession = (type: typeof activeSessionType) => {
    const newSession: CoachingSession = {
      id: Date.now().toString(),
      type,
      messages: [{
        id: Date.now().toString(),
        text: getWelcomeMessage(type),
        sender: 'ai',
        timestamp: new Date()
      }],
      startedAt: new Date(),
      status: 'active'
    };

    dispatch({ type: 'ADD_COACHING_SESSION', payload: newSession });
    setActiveSessionType(type);
  };

  const getWelcomeMessage = (type: string): string => {
    const messages = {
      'resume-review': "Hello! I'm your AI Resume Coach. I've analyzed thousands of resumes and I'm here to help you create a standout application. What specific aspect of your resume would you like to improve?",
      'career-guidance': "Hi there! I'm your Career Guidance Counselor. I can help you navigate career transitions, identify growth opportunities, and plan your professional development. What career questions are on your mind?",
      'interview-prep': "Welcome! I'm your Interview Preparation Coach. I'll help you practice common questions, develop compelling stories, and build confidence for your upcoming interviews. What type of interview are you preparing for?",
      'skill-assessment': "Greetings! I'm your Skills Assessment Advisor. I can help you identify skill gaps, recommend learning paths, and create development plans. What skills would you like to evaluate or improve?"
    };
    return messages[type as keyof typeof messages] || messages['resume-review'];
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || !state.activeCoachingSession) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: inputMessage,
      sender: 'user',
      timestamp: new Date(),
    };

    const currentSession = state.coachingSessions.find(s => s.id === state.activeCoachingSession);
    if (!currentSession) return;

    const updatedMessages = [...currentSession.messages, userMessage];
    dispatch({ 
      type: 'UPDATE_COACHING_SESSION', 
      payload: { id: state.activeCoachingSession, messages: updatedMessages }
    });

    setInputMessage('');
    setIsTyping(true);

    try {
      const aiResponse = await generateCoachResponse(inputMessage, currentSession.type, {
        resume: state.resume,
        analysis: state.coachAnalysis
      });
      
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: aiResponse,
        sender: 'ai',
        timestamp: new Date(),
      };

      const finalMessages = [...updatedMessages, aiMessage];
      dispatch({ 
        type: 'UPDATE_COACHING_SESSION', 
        payload: { id: state.activeCoachingSession, messages: finalMessages }
      });
    } catch (error) {
      console.error('Failed to get coach response:', error);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const activeSession = state.coachingSessions.find(s => s.id === state.activeCoachingSession);

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-green-400';
    if (score >= 70) return 'text-cyan-400';
    if (score >= 55) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <AlertCircle className="h-4 w-4 text-red-400" />;
      case 'medium': return <Clock className="h-4 w-4 text-yellow-400" />;
      case 'low': return <CheckCircle className="h-4 w-4 text-green-400" />;
      default: return <CheckCircle className="h-4 w-4 text-slate-400" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
          AI Career Coach
        </h1>
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Get personalized career guidance, resume reviews, and professional development 
          advice from your AI-powered career coach.
        </p>
      </motion.div>

      {/* Coach Analysis Section */}
      {!state.coachAnalysis && !state.isCoachAnalyzing && state.resume && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-8 text-center"
        >
          <div className="mb-6">
            <Brain className="h-16 w-16 text-purple-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-2">Get Your Comprehensive Career Analysis</h3>
            <p className="text-slate-300">
              Let our AI coach analyze your resume and provide detailed, personalized feedback 
              to accelerate your career growth.
            </p>
          </div>
          
          <motion.button
            onClick={startCoachAnalysis}
            className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 rounded-xl font-bold text-lg text-white shadow-2xl shadow-purple-500/25 transition-all"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="flex items-center space-x-3">
              <Sparkles className="h-6 w-6" />
              <span>Start Career Analysis</span>
            </div>
          </motion.button>
        </motion.div>
      )}

      {/* Loading State */}
      {state.isCoachAnalyzing && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-8 text-center"
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
            className="mb-4"
          >
            <Brain className="h-16 w-16 text-purple-400 mx-auto" />
          </motion.div>
          <h3 className="text-xl font-bold text-white mb-2">Analyzing Your Career Profile...</h3>
          <p className="text-slate-300">
            Our AI is conducting a comprehensive review of your resume, skills, and career trajectory.
          </p>
        </motion.div>
      )}

      {/* Analysis Results */}
      {state.coachAnalysis && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* Overview Cards */}
          <div className="xl:col-span-1 space-y-6">
            {/* Confidence & Market Readiness */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
            >
              <div className="flex items-center space-x-3 mb-4">
                <BarChart3 className="h-6 w-6 text-cyan-400" />
                <h3 className="text-lg font-bold text-white">Career Metrics</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-300">Confidence Score</span>
                    <span className={`font-bold ${getScoreColor(state.coachAnalysis.confidenceScore)}`}>
                      {state.coachAnalysis.confidenceScore}%
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-600 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-cyan-500 to-blue-600"
                      initial={{ width: 0 }}
                      animate={{ width: `${state.coachAnalysis.confidenceScore}%` }}
                      transition={{ duration: 1, delay: 0.5 }}
                    />
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-300">Market Readiness</span>
                    <span className={`font-bold ${getScoreColor(state.coachAnalysis.marketReadiness)}`}>
                      {state.coachAnalysis.marketReadiness}%
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-600 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-purple-500 to-pink-600"
                      initial={{ width: 0 }}
                      animate={{ width: `${state.coachAnalysis.marketReadiness}%` }}
                      transition={{ duration: 1, delay: 0.7 }}
                    />
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Strengths & Weaknesses */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
            >
              <div className="flex items-center space-x-3 mb-4">
                <Target className="h-6 w-6 text-green-400" />
                <h3 className="text-lg font-bold text-white">Key Strengths</h3>
              </div>
              <div className="space-y-2">
                {state.coachAnalysis.strengths.map((strength, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 + index * 0.1 }}
                    className="flex items-center space-x-2"
                  >
                    <CheckCircle className="h-4 w-4 text-green-400 flex-shrink-0" />
                    <span className="text-slate-300 text-sm">{strength}</span>
                  </motion.div>
                ))}
              </div>
              
              <div className="mt-6">
                <div className="flex items-center space-x-3 mb-4">
                  <AlertCircle className="h-6 w-6 text-yellow-400" />
                  <h3 className="text-lg font-bold text-white">Areas for Growth</h3>
                </div>
                <div className="space-y-2">
                  {state.coachAnalysis.weaknesses.map((weakness, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.8 + index * 0.1 }}
                      className="flex items-center space-x-2"
                    >
                      <TrendingUp className="h-4 w-4 text-yellow-400 flex-shrink-0" />
                      <span className="text-slate-300 text-sm">{weakness}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>

          {/* Detailed Analysis */}
          <div className="xl:col-span-2 space-y-6">
            {/* Overall Assessment */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
            >
              <div className="flex items-center space-x-3 mb-4">
                <Brain className="h-6 w-6 text-purple-400" />
                <h3 className="text-xl font-bold text-white">AI Assessment</h3>
              </div>
              <p className="text-slate-300 leading-relaxed">{state.coachAnalysis.overallAssessment}</p>
            </motion.div>

            {/* Detailed Feedback */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
            >
              <div className="flex items-center space-x-3 mb-6">
                <Award className="h-6 w-6 text-yellow-400" />
                <h3 className="text-xl font-bold text-white">Detailed Feedback</h3>
              </div>
              
              <div className="space-y-6">
                {state.coachAnalysis.detailedFeedback.map((feedback, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    className="border-l-4 border-l-cyan-400 bg-slate-700/30 p-4 rounded-r-lg"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-white">{feedback.section}</h4>
                      <div className="flex items-center space-x-2">
                        {getPriorityIcon(feedback.priority)}
                        <span className="text-xs text-slate-400 uppercase">{feedback.priority}</span>
                      </div>
                    </div>
                    <p className="text-slate-300 text-sm mb-3">{feedback.feedback}</p>
                    <div className="space-y-1">
                      {feedback.suggestions.map((suggestion, suggestionIndex) => (
                        <div key={suggestionIndex} className="flex items-start space-x-2">
                          <span className="text-cyan-400 text-xs mt-1">•</span>
                          <span className="text-slate-400 text-xs">{suggestion}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Next Steps */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
            >
              <div className="flex items-center space-x-3 mb-4">
                <BookOpen className="h-6 w-6 text-blue-400" />
                <h3 className="text-xl font-bold text-white">Recommended Next Steps</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {state.coachAnalysis.nextSteps.map((step, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                    className="flex items-start space-x-3 p-3 bg-slate-700/30 rounded-lg"
                  >
                    <span className="flex-shrink-0 w-6 h-6 bg-blue-400 text-slate-900 rounded-full flex items-center justify-center text-xs font-bold">
                      {index + 1}
                    </span>
                    <span className="text-slate-300 text-sm">{step}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      )}

      {/* Coaching Sessions */}
      {state.coachAnalysis && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
        >
          <div className="flex items-center space-x-3 mb-6">
            <Users className="h-6 w-6 text-purple-400" />
            <h3 className="text-xl font-bold text-white">1-on-1 Coaching Sessions</h3>
          </div>

          {/* Session Type Selector */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {[
              { type: 'resume-review', icon: FileText, label: 'Resume Review', color: 'cyan' },
              { type: 'career-guidance', icon: TrendingUp, label: 'Career Guidance', color: 'green' },
              { type: 'interview-prep', icon: MessageCircle, label: 'Interview Prep', color: 'yellow' },
              { type: 'skill-assessment', icon: Award, label: 'Skill Assessment', color: 'purple' }
            ].map(({ type, icon: Icon, label, color }) => (
              <motion.button
                key={type}
                onClick={() => startCoachingSession(type as any)}
                className={`p-4 rounded-lg border-2 transition-all ${
                  activeSessionType === type
                    ? `border-${color}-400 bg-${color}-400/20`
                    : 'border-slate-600 hover:border-slate-500'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Icon className={`h-6 w-6 mx-auto mb-2 ${
                  activeSessionType === type ? `text-${color}-400` : 'text-slate-400'
                }`} />
                <p className={`text-sm font-medium ${
                  activeSessionType === type ? 'text-white' : 'text-slate-300'
                }`}>
                  {label}
                </p>
              </motion.button>
            ))}
          </div>

          {/* Chat Interface */}
          {activeSession && (
            <div className="border border-slate-600 rounded-lg overflow-hidden">
              {/* Chat Messages */}
              <div className="h-96 overflow-y-auto p-4 space-y-4 bg-slate-900/50">
                {activeSession.messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex items-start space-x-3 ${
                      message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                    }`}
                  >
                    <div className={`p-2 rounded-lg ${
                      message.sender === 'user' 
                        ? 'bg-cyan-400/20' 
                        : 'bg-purple-400/20'
                    }`}>
                      {message.sender === 'user' ? (
                        <User className="h-4 w-4 text-cyan-400" />
                      ) : (
                        <Brain className="h-4 w-4 text-purple-400" />
                      )}
                    </div>
                    <div className={`flex-1 ${
                      message.sender === 'user' ? 'text-right' : ''
                    }`}>
                      <div className={`inline-block p-3 rounded-lg max-w-xs lg:max-w-md ${
                        message.sender === 'user'
                          ? 'bg-cyan-600 text-white'
                          : 'bg-slate-700 text-slate-200'
                      }`}>
                        <p className="text-sm leading-relaxed">{message.text}</p>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </motion.div>
                ))}

                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex items-start space-x-3"
                  >
                    <div className="p-2 bg-purple-400/20 rounded-lg">
                      <Brain className="h-4 w-4 text-purple-400" />
                    </div>
                    <div className="bg-slate-700 rounded-lg p-3">
                      <div className="flex space-x-1">
                        {[0, 1, 2].map((i) => (
                          <motion.div
                            key={i}
                            className="w-2 h-2 bg-purple-400 rounded-full"
                            animate={{ opacity: [0.4, 1, 0.4] }}
                            transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                          />
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Input Area */}
              <div className="p-4 border-t border-slate-600 bg-slate-800/50">
                <div className="flex space-x-3">
                  <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask your AI coach anything..."
                    className="flex-1 px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <motion.button
                    onClick={sendMessage}
                    disabled={!inputMessage.trim() || isTyping}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-slate-600 disabled:cursor-not-allowed rounded-lg transition-colors"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Send className="h-5 w-5 text-white" />
                  </motion.button>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      )}

      {/* No Resume State */}
      {!state.resume && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-8 text-center"
        >
          <Briefcase className="h-16 w-16 text-slate-400 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-white mb-2">Upload Your Resume First</h3>
          <p className="text-slate-300 mb-6">
            To get personalized career coaching, please upload your resume in the Resume Analysis tab.
          </p>
          <motion.button
            onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'analyze' })}
            className="px-6 py-3 bg-cyan-600 hover:bg-cyan-700 rounded-lg text-white font-medium transition-colors"
            whileHover={{ scale: 1.05 }}
          >
            Go to Resume Analysis
          </motion.button>
        </motion.div>
      )}
    </div>
  );
};

export default AICoach;