import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Target, TrendingUp } from 'lucide-react';
import { AnalysisResult } from '../types';

interface ScoreDisplayProps {
  result: AnalysisResult;
}

const ScoreDisplay: React.FC<ScoreDisplayProps> = ({ result }) => {
  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-green-400';
    if (score >= 70) return 'text-cyan-400';
    if (score >= 55) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getScoreGradient = (score: number) => {
    if (score >= 85) return 'from-green-500 to-emerald-600';
    if (score >= 70) return 'from-cyan-500 to-blue-600';
    if (score >= 55) return 'from-yellow-500 to-orange-600';
    return 'from-red-500 to-rose-600';
  };

  const breakdownItems = [
    { key: 'skills', label: 'Skills', icon: '🛠️' },
    { key: 'experience', label: 'Experience', icon: '💼' },
    { key: 'education', label: 'Education', icon: '🎓' },
    { key: 'achievements', label: 'Achievements', icon: '🏆' },
    { key: 'language', label: 'Language', icon: '✍️' },
    { key: 'layout', label: 'Layout', icon: '📋' },
    { key: 'atsOptimization', label: 'ATS Score', icon: '🤖' },
  ];

  return (
    <div className="space-y-6">
      {/* Overall Score */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-8 text-center"
      >
        <div className="flex items-center justify-center space-x-3 mb-4">
          <Trophy className="h-8 w-8 text-yellow-400" />
          <h3 className="text-2xl font-bold text-white">Overall Score</h3>
        </div>
        
        <div className="relative w-32 h-32 mx-auto mb-4">
          {/* Background Circle */}
          <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 128 128">
            <circle
              cx="64"
              cy="64"
              r="56"
              stroke="currentColor"
              strokeWidth="8"
              fill="none"
              className="text-slate-700"
            />
            {/* Progress Circle */}
            <motion.circle
              cx="64"
              cy="64"
              r="56"
              stroke="url(#scoreGradient)"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={351.86}
              initial={{ strokeDashoffset: 351.86 }}
              animate={{ strokeDashoffset: 351.86 - (351.86 * result.overallScore) / 100 }}
              transition={{ duration: 2, ease: 'easeOut' }}
            />
            <defs>
              <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" className="stop-cyan-500" />
                <stop offset="100%" className="stop-purple-500" />
              </linearGradient>
            </defs>
          </svg>
          
          {/* Score Text */}
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className={`text-3xl font-bold ${getScoreColor(result.overallScore)}`}
            >
              {result.overallScore}
            </motion.span>
          </div>
        </div>
        
        <p className="text-slate-300">
          {result.overallScore >= 85 && 'Excellent! Your resume is highly optimized.'}
          {result.overallScore >= 70 && result.overallScore < 85 && 'Good! Some improvements needed.'}
          {result.overallScore >= 55 && result.overallScore < 70 && 'Average. Consider significant improvements.'}
          {result.overallScore < 55 && 'Needs work. Major improvements required.'}
        </p>
      </motion.div>

      {/* Score Breakdown */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
      >
        <div className="flex items-center space-x-3 mb-6">
          <Target className="h-6 w-6 text-cyan-400" />
          <h3 className="text-xl font-bold text-white">Score Breakdown</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {breakdownItems.map((item, index) => {
            const score = result.breakdown[item.key as keyof typeof result.breakdown];
            return (
              <motion.div
                key={item.key}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 + index * 0.1 }}
                className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg"
              >
                <div className="flex items-center space-x-3">
                  <span className="text-xl">{item.icon}</span>
                  <span className="text-slate-200 font-medium">{item.label}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-24 h-2 bg-slate-600 rounded-full overflow-hidden">
                    <motion.div
                      className={`h-full bg-gradient-to-r ${getScoreGradient(score)}`}
                      initial={{ width: 0 }}
                      animate={{ width: `${score}%` }}
                      transition={{ delay: 1 + index * 0.1, duration: 0.8 }}
                    />
                  </div>
                  <span className={`text-sm font-bold w-8 ${getScoreColor(score)}`}>
                    {score}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      {/* ATS Compatibility */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
      >
        <div className="flex items-center space-x-3 mb-4">
          <TrendingUp className="h-6 w-6 text-green-400" />
          <h3 className="text-xl font-bold text-white">ATS Compatibility</h3>
        </div>
        
        <div className="flex items-center justify-between">
          <p className="text-slate-300">
            Your resume's compatibility with Applicant Tracking Systems
          </p>
          <div className={`text-2xl font-bold ${getScoreColor(result.atsCompatibility)}`}>
            {result.atsCompatibility}%
          </div>
        </div>
        
        <div className="mt-3 w-full h-3 bg-slate-600 rounded-full overflow-hidden">
          <motion.div
            className={`h-full bg-gradient-to-r ${getScoreGradient(result.atsCompatibility)}`}
            initial={{ width: 0 }}
            animate={{ width: `${result.atsCompatibility}%` }}
            transition={{ delay: 1.2, duration: 1 }}
          />
        </div>
      </motion.div>
    </div>
  );
};

export default ScoreDisplay;