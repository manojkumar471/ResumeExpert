import React from 'react';
import { motion } from 'framer-motion';
import { Lightbulb, AlertTriangle, Plus, Zap } from 'lucide-react';
import { AnalysisResult } from '../types';
import { SUGGESTION_TYPES } from '../utils/constants';

interface SuggestionsPanelProps {
  result: AnalysisResult;
}

const SuggestionsPanel: React.FC<SuggestionsPanelProps> = ({ result }) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'improvement': return <Zap className="h-4 w-4" />;
      case 'addition': return <Plus className="h-4 w-4" />;
      case 'warning': return <AlertTriangle className="h-4 w-4" />;
      default: return <Lightbulb className="h-4 w-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-400/20 text-red-400 border-red-400/50';
      case 'medium': return 'bg-yellow-400/20 text-yellow-400 border-yellow-400/50';
      case 'low': return 'bg-green-400/20 text-green-400 border-green-400/50';
      default: return 'bg-slate-400/20 text-slate-400 border-slate-400/50';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
    >
      <div className="flex items-center space-x-3 mb-6">
        <div className="p-2 bg-yellow-400/20 rounded-lg">
          <Lightbulb className="h-6 w-6 text-yellow-400" />
        </div>
        <h3 className="text-xl font-bold text-white">AI Suggestions</h3>
      </div>

      <div className="space-y-4">
        {result.suggestions.map((suggestion, index) => (
          <motion.div
            key={suggestion.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`p-4 rounded-lg border-l-4 ${SUGGESTION_TYPES[suggestion.type].color}`}
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center space-x-2">
                {getIcon(suggestion.type)}
                <span className="font-medium text-white">{suggestion.section}</span>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getPriorityColor(suggestion.priority)}`}>
                {suggestion.priority.toUpperCase()}
              </span>
            </div>
            <p className="text-slate-300 text-sm leading-relaxed">
              {suggestion.message}
            </p>
          </motion.div>
        ))}
      </div>

      {/* Keywords Section */}
      <div className="mt-8 pt-6 border-t border-slate-700">
        <h4 className="text-lg font-semibold text-white mb-4">Keyword Analysis</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h5 className="text-sm font-medium text-green-400 mb-3 flex items-center space-x-2">
              <span className="w-2 h-2 bg-green-400 rounded-full"></span>
              <span>Matched Keywords ({result.keywords.matched.length})</span>
            </h5>
            <div className="flex flex-wrap gap-2">
              {result.keywords.matched.map((keyword, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + index * 0.05 }}
                  className="px-3 py-1 bg-green-400/20 text-green-400 rounded-full text-sm font-medium"
                >
                  {keyword}
                </motion.span>
              ))}
            </div>
          </div>

          <div>
            <h5 className="text-sm font-medium text-red-400 mb-3 flex items-center space-x-2">
              <span className="w-2 h-2 bg-red-400 rounded-full"></span>
              <span>Missing Keywords ({result.keywords.missing.length})</span>
            </h5>
            <div className="flex flex-wrap gap-2">
              {result.keywords.missing.map((keyword, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.7 + index * 0.05 }}
                  className="px-3 py-1 bg-red-400/20 text-red-400 rounded-full text-sm font-medium"
                >
                  {keyword}
                </motion.span>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-4 p-3 bg-slate-700/50 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-slate-300">Keyword Relevance Score</span>
            <span className="text-cyan-400 font-bold">{result.keywords.relevanceScore}%</span>
          </div>
          <div className="mt-2 w-full h-2 bg-slate-600 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-600"
              initial={{ width: 0 }}
              animate={{ width: `${result.keywords.relevanceScore}%` }}
              transition={{ delay: 1, duration: 1 }}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default SuggestionsPanel;