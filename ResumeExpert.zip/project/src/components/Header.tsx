import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Zap, Moon, Sun } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

const Header: React.FC = () => {
  const { state, dispatch } = useAppContext();

  const toggleDarkMode = () => {
    dispatch({ type: 'TOGGLE_DARK_MODE' });
  };

  return (
    <motion.header
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-lg sticky top-0 z-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <motion.div
            className="flex items-center space-x-3"
            whileHover={{ scale: 1.05 }}
          >
            <div className="relative">
              <Brain className="h-8 w-8 text-cyan-400" />
              <motion.div
                className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                ResumeXpert
              </h1>
              <p className="text-xs text-slate-400">AI-Powered Resume Analysis</p>
            </div>
          </motion.div>

          <div className="flex items-center space-x-4">
            <motion.div
              className="flex items-center space-x-2 px-3 py-1 bg-slate-800/50 rounded-lg border border-slate-700"
              whileHover={{ borderColor: '#06B6D4' }}
            >
              <Zap className="h-4 w-4 text-yellow-400" />
              <span className="text-sm text-slate-300">Beta</span>
            </motion.div>

            <motion.button
              onClick={toggleDarkMode}
              className="p-2 text-slate-400 hover:text-cyan-400 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              {state.isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </motion.button>
          </div>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;