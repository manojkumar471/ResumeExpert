import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Sparkles } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { useResumeAnalysis } from '../hooks/useResumeAnalysis';

const AnalysisButton: React.FC = () => {
  const { state } = useAppContext();
  const { startAnalysis, isAnalyzing } = useResumeAnalysis();

  const canAnalyze = state.resume && !isAnalyzing;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center"
    >
      <motion.button
        onClick={startAnalysis}
        disabled={!canAnalyze}
        className={`relative px-8 py-4 rounded-xl font-bold text-lg transition-all ${
          canAnalyze
            ? 'bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white shadow-2xl shadow-cyan-500/25'
            : 'bg-slate-700 text-slate-400 cursor-not-allowed'
        }`}
        whileHover={canAnalyze ? { scale: 1.05, boxShadow: '0 25px 50px -12px rgba(6, 182, 212, 0.4)' } : {}}
        whileTap={canAnalyze ? { scale: 0.95 } : {}}
      >
        <div className="flex items-center space-x-3">
          {isAnalyzing ? (
            <>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
              >
                <Sparkles className="h-6 w-6" />
              </motion.div>
              <span>Analyzing Resume...</span>
            </>
          ) : (
            <>
              <Zap className="h-6 w-6" />
              <span>Analyze with AI</span>
            </>
          )}
        </div>
        
        {canAnalyze && (
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-xl opacity-20"
            animate={{ opacity: [0.2, 0.4, 0.2] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
      </motion.button>

      {!state.resume && (
        <p className="mt-3 text-sm text-slate-400">
          Upload your resume to get started
        </p>
      )}
    </motion.div>
  );
};

export default AnalysisButton;