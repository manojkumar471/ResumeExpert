import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Briefcase, Building, Save, X } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { INDUSTRIES } from '../utils/constants';

const JobDescriptionInput: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const [isExpanded, setIsExpanded] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    company: '',
    content: '',
    industry: 'tech',
  });

  const handleSave = () => {
    if (!formData.title || !formData.content) return;

    dispatch({
      type: 'SET_JOB_DESCRIPTION',
      payload: {
        title: formData.title,
        company: formData.company,
        content: formData.content,
        industry: formData.industry,
      },
    });
    setIsExpanded(false);
  };

  const handleClear = () => {
    dispatch({ type: 'SET_JOB_DESCRIPTION', payload: null });
    setFormData({ title: '', company: '', content: '', industry: 'tech' });
  };

  if (state.jobDescription && !isExpanded) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-purple-400/20 rounded-lg">
              <Briefcase className="h-6 w-6 text-purple-400" />
            </div>
            <div>
              <h3 className="font-medium text-white">{state.jobDescription.title}</h3>
              {state.jobDescription.company && (
                <p className="text-sm text-slate-400">{state.jobDescription.company}</p>
              )}
            </div>
          </div>
          <div className="flex space-x-2">
            <motion.button
              onClick={() => setIsExpanded(true)}
              className="px-3 py-1 bg-slate-700 hover:bg-slate-600 rounded-lg text-sm transition-colors"
              whileHover={{ scale: 1.05 }}
            >
              Edit
            </motion.button>
            <motion.button
              onClick={handleClear}
              className="p-2 text-slate-400 hover:text-red-400 transition-colors"
              whileHover={{ scale: 1.1 }}
            >
              <X className="h-4 w-4" />
            </motion.button>
          </div>
        </div>
        <p className="text-sm text-slate-300 line-clamp-3">
          {state.jobDescription.content.substring(0, 200)}...
        </p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-purple-400/20 rounded-lg">
            <Briefcase className="h-6 w-6 text-purple-400" />
          </div>
          <h3 className="text-lg font-semibold text-white">Job Description (Optional)</h3>
        </div>
        {!isExpanded && (
          <motion.button
            onClick={() => setIsExpanded(true)}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg text-white text-sm font-medium transition-colors"
            whileHover={{ scale: 1.05 }}
          >
            Add Job Description
          </motion.button>
        )}
      </div>

      {isExpanded && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="space-y-4"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Job Title *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="e.g. Senior Software Engineer"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Company
              </label>
              <div className="relative">
                <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="w-full pl-10 pr-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="e.g. TechCorp Inc."
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Industry
            </label>
            <select
              value={formData.industry}
              onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
              className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
            >
              {INDUSTRIES.map((industry) => (
                <option key={industry.value} value={industry.value}>
                  {industry.icon} {industry.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Job Description *
            </label>
            <textarea
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              rows={8}
              className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
              placeholder="Paste the full job description here..."
            />
          </div>

          <div className="flex justify-end space-x-3">
            <motion.button
              onClick={() => setIsExpanded(false)}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
              whileHover={{ scale: 1.05 }}
            >
              Cancel
            </motion.button>
            <motion.button
              onClick={handleSave}
              disabled={!formData.title || !formData.content}
              className="flex items-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-slate-600 disabled:cursor-not-allowed rounded-lg text-white font-medium transition-colors"
              whileHover={{ scale: 1.05 }}
            >
              <Save className="h-4 w-4" />
              <span>Save</span>
            </motion.button>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default JobDescriptionInput;