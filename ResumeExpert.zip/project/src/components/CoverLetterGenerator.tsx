import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Send, Copy, Download, Sparkles, User, Building, MessageSquare, MapPin, Calendar, Award, StickyNote } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { generateCoverLetter } from '../utils/aiMockServices';
import { CoverLetterRequest } from '../types';

const CoverLetterGenerator: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const [formData, setFormData] = useState<CoverLetterRequest>({
    resumeContent: state.resume?.content || '',
    jobTitle: state.jobDescription?.title || '',
    jobDescription: state.jobDescription?.content || '',
    companyName: state.jobDescription?.company || '',
    tone: 'professional' as any,
    candidateLocation: '',
    yearsExperience: '',
    specificAchievements: '',
    additionalNotes: '',
  });

  const [selectedCoverLetter, setSelectedCoverLetter] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!formData.jobTitle || !formData.jobDescription) return;

    dispatch({ type: 'SET_GENERATING_COVER_LETTER', payload: true });

    try {
      const result = await generateCoverLetter(formData);
      dispatch({ type: 'ADD_COVER_LETTER', payload: result });
      setSelectedCoverLetter(result.id);
    } catch (error) {
      console.error('Failed to generate cover letter:', error);
      dispatch({ type: 'SET_GENERATING_COVER_LETTER', payload: false });
    }
  };

  const copyToClipboard = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  const downloadCoverLetter = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const selectedLetter = state.coverLetters.find(letter => letter.id === selectedCoverLetter);

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
          AI Cover Letter Generator
        </h1>
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Create professional, tailored cover letters that complement your resume 
          and match specific job requirements using advanced AI technology.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {/* Form Section */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
        >
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-purple-400/20 rounded-lg">
              <FileText className="h-6 w-6 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold text-white">Cover Letter Details</h3>
          </div>

          <div className="space-y-6">
            {/* Job Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="flex items-center space-x-2 text-sm font-medium text-slate-300 mb-2">
                  <User className="h-4 w-4" />
                  <span>Job Title *</span>
                </label>
                <input
                  type="text"
                  value={formData.jobTitle}
                  onChange={(e) => setFormData({ ...formData, jobTitle: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="e.g. Senior Software Engineer"
                />
              </div>
              <div>
                <label className="flex items-center space-x-2 text-sm font-medium text-slate-300 mb-2">
                  <Building className="h-4 w-4" />
                  <span>Company Name</span>
                </label>
                <input
                  type="text"
                  value={formData.companyName}
                  onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="e.g. TechCorp Inc."
                />
              </div>
            </div>

            {/* Tone Selection */}
            <div>
              <label className="flex items-center space-x-2 text-sm font-medium text-slate-300 mb-2">
                <MessageSquare className="h-4 w-4" />
                <span>Tone</span>
              </label>
              <select
                value={formData.tone}
                onChange={(e) => setFormData({ ...formData, tone: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="friendly">Friendly</option>
                <option value="formal">Formal</option>
                <option value="confident">Confident</option>
                <option value="assertive">Assertive</option>
              </select>
            </div>

            {/* Job Description */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Job Description *
              </label>
              <textarea
                value={formData.jobDescription}
                onChange={(e) => setFormData({ ...formData, jobDescription: e.target.value })}
                rows={6}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                placeholder="Paste the job description here..."
              />
            </div>

            {/* Optional Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="flex items-center space-x-2 text-sm font-medium text-slate-300 mb-2">
                  <MapPin className="h-4 w-4" />
                  <span>Location (Optional)</span>
                </label>
                <input
                  type="text"
                  value={formData.candidateLocation}
                  onChange={(e) => setFormData({ ...formData, candidateLocation: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="e.g. San Francisco, CA"
                />
              </div>
              <div>
                <label className="flex items-center space-x-2 text-sm font-medium text-slate-300 mb-2">
                  <Calendar className="h-4 w-4" />
                  <span>Years of Experience</span>
                </label>
                <input
                  type="text"
                  value={formData.yearsExperience}
                  onChange={(e) => setFormData({ ...formData, yearsExperience: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="e.g. 5+ years"
                />
              </div>
            </div>

            <div>
              <label className="flex items-center space-x-2 text-sm font-medium text-slate-300 mb-2">
                <Award className="h-4 w-4" />
                <span>Key Achievements to Highlight</span>
              </label>
              <textarea
                value={formData.specificAchievements}
                onChange={(e) => setFormData({ ...formData, specificAchievements: e.target.value })}
                rows={3}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                placeholder="e.g. Led team of 10, increased revenue by 40%, launched 3 major products..."
              />
            </div>

            <div>
              <label className="flex items-center space-x-2 text-sm font-medium text-slate-300 mb-2">
                <StickyNote className="h-4 w-4" />
                <span>Additional Notes</span>
              </label>
              <textarea
                value={formData.additionalNotes}
                onChange={(e) => setFormData({ ...formData, additionalNotes: e.target.value })}
                rows={2}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                placeholder="Any specific points you want to emphasize..."
              />
            </div>

            {/* Generate Button */}
            <motion.button
              onClick={handleGenerate}
              disabled={!formData.jobTitle || !formData.jobDescription || state.isGeneratingCoverLetter}
              className={`w-full py-3 rounded-xl font-bold text-lg transition-all ${
                formData.jobTitle && formData.jobDescription && !state.isGeneratingCoverLetter
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-2xl shadow-purple-500/25'
                  : 'bg-slate-700 text-slate-400 cursor-not-allowed'
              }`}
              whileHover={formData.jobTitle && formData.jobDescription && !state.isGeneratingCoverLetter ? { scale: 1.02 } : {}}
              whileTap={formData.jobTitle && formData.jobDescription && !state.isGeneratingCoverLetter ? { scale: 0.98 } : {}}
            >
              <div className="flex items-center justify-center space-x-3">
                {state.isGeneratingCoverLetter ? (
                  <>
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                    >
                      <Sparkles className="h-6 w-6" />
                    </motion.div>
                    <span>Generating Cover Letter...</span>
                  </>
                ) : (
                  <>
                    <Send className="h-6 w-6" />
                    <span>Generate Cover Letter</span>
                  </>
                )}
              </div>
            </motion.button>
          </div>
        </motion.div>

        {/* Results Section */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          {/* Cover Letter History */}
          {state.coverLetters.length > 0 && (
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">Generated Cover Letters</h3>
              <div className="space-y-3">
                {state.coverLetters.map((letter) => (
                  <motion.div
                    key={letter.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`p-4 rounded-lg border cursor-pointer transition-all ${
                      selectedCoverLetter === letter.id
                        ? 'border-purple-500 bg-purple-500/10'
                        : 'border-slate-600 hover:border-slate-500'
                    }`}
                    onClick={() => setSelectedCoverLetter(letter.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-white">{letter.jobTitle}</p>
                        <p className="text-sm text-slate-400">
                          {letter.companyName} • {letter.tone} tone
                        </p>
                      </div>
                      <p className="text-xs text-slate-500">
                        {letter.generatedAt.toLocaleDateString()}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Selected Cover Letter Display */}
          {selectedLetter && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white">Cover Letter Preview</h3>
                <div className="flex space-x-2">
                  <motion.button
                    onClick={() => copyToClipboard(selectedLetter.content)}
                    className="p-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-slate-300 hover:text-white transition-colors"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Copy className="h-4 w-4" />
                  </motion.button>
                  <motion.button
                    onClick={() => downloadCoverLetter(selectedLetter.content, `cover-letter-${selectedLetter.jobTitle}`)}
                    className="p-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-slate-300 hover:text-white transition-colors"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Download className="h-4 w-4" />
                  </motion.button>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg text-gray-900 font-mono text-sm leading-relaxed max-h-96 overflow-y-auto">
                <pre className="whitespace-pre-wrap">{selectedLetter.content}</pre>
              </div>
            </motion.div>
          )}

          {/* Empty State */}
          {state.coverLetters.length === 0 && !state.isGeneratingCoverLetter && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-8 text-center"
            >
              <FileText className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-white mb-2">No Cover Letters Yet</h3>
              <p className="text-slate-400">
                Fill out the form and generate your first AI-powered cover letter
              </p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default CoverLetterGenerator;