import React from 'react';
import { motion } from 'framer-motion';
import { Eye, Target } from 'lucide-react';
import { AnalysisResult } from '../types';

interface HeatmapVisualizationProps {
  result: AnalysisResult;
}

const HeatmapVisualization: React.FC<HeatmapVisualizationProps> = ({ result }) => {
  const getHeatColor = (similarity: number) => {
    if (similarity >= 80) return 'bg-green-500';
    if (similarity >= 60) return 'bg-yellow-500';
    if (similarity >= 40) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const getTextColor = (similarity: number) => {
    if (similarity >= 80) return 'text-green-400';
    if (similarity >= 60) return 'text-yellow-400';
    if (similarity >= 40) return 'text-orange-400';
    return 'text-red-400';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
    >
      <div className="flex items-center space-x-3 mb-6">
        <div className="p-2 bg-indigo-400/20 rounded-lg">
          <Eye className="h-6 w-6 text-indigo-400" />
        </div>
        <h3 className="text-xl font-bold text-white">Resume-JD Similarity Heatmap</h3>
      </div>

      <div className="space-y-4">
        {result.heatmapData.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 bg-slate-700/50 rounded-lg"
          >
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-white">{item.section}</h4>
              <div className="flex items-center space-x-2">
                <span className={`text-sm font-bold ${getTextColor(item.similarity)}`}>
                  {item.similarity}%
                </span>
                <Target className="h-4 w-4 text-slate-400" />
              </div>
            </div>

            {/* Similarity Bar */}
            <div className="w-full h-3 bg-slate-600 rounded-full overflow-hidden mb-3">
              <motion.div
                className={`h-full ${getHeatColor(item.similarity)}`}
                initial={{ width: 0 }}
                animate={{ width: `${item.similarity}%` }}
                transition={{ delay: 0.5 + index * 0.1, duration: 0.8 }}
              />
            </div>

            {/* Keywords */}
            <div>
              <p className="text-xs text-slate-400 mb-2">Key matching terms:</p>
              <div className="flex flex-wrap gap-2">
                {item.keywords.map((keyword, keywordIndex) => (
                  <motion.span
                    key={keywordIndex}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.7 + index * 0.1 + keywordIndex * 0.05 }}
                    className="px-2 py-1 bg-indigo-400/20 text-indigo-300 rounded text-xs font-medium"
                  >
                    {keyword}
                  </motion.span>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Legend */}
      <div className="mt-6 pt-4 border-t border-slate-700">
        <p className="text-sm text-slate-400 mb-3">Similarity Scale:</p>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded"></div>
            <span className="text-xs text-slate-400">0-39%</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-orange-500 rounded"></div>
            <span className="text-xs text-slate-400">40-59%</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-yellow-500 rounded"></div>
            <span className="text-xs text-slate-400">60-79%</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span className="text-xs text-slate-400">80-100%</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default HeatmapVisualization;