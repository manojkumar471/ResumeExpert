import React from 'react';
import { motion } from 'framer-motion';
import { Settings, User, Briefcase } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { INDUSTRIES, CAREER_LEVELS } from '../utils/constants';

const PreferencesSection: React.FC = () => {
  const { state, dispatch } = useAppContext();

  const updatePreference = (key: string, value: any) => {
    dispatch({ type: 'SET_PREFERENCES', payload: { [key]: value } });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6"
    >
      <div className="flex items-center space-x-3 mb-6">
        <div className="p-2 bg-blue-400/20 rounded-lg">
          <Settings className="h-6 w-6 text-blue-400" />
        </div>
        <h3 className="text-lg font-semibold text-white">Analysis Preferences</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="flex items-center space-x-2 text-sm font-medium text-slate-300 mb-3">
            <Briefcase className="h-4 w-4" />
            <span>Target Industry</span>
          </label>
          <select
            value={state.preferences.industry}
            onChange={(e) => updatePreference('industry', e.target.value)}
            className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {INDUSTRIES.map((industry) => (
              <option key={industry.value} value={industry.value}>
                {industry.icon} {industry.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="flex items-center space-x-2 text-sm font-medium text-slate-300 mb-3">
            <User className="h-4 w-4" />
            <span>Career Level</span>
          </label>
          <select
            value={state.preferences.careerLevel}
            onChange={(e) => updatePreference('careerLevel', e.target.value)}
            className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {CAREER_LEVELS.map((level) => (
              <option key={level.value} value={level.value}>
                {level.icon} {level.label}
              </option>
            ))}
          </select>
        </div>
      </div>
    </motion.div>
  );
};

export default PreferencesSection;