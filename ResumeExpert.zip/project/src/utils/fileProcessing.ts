import { ResumeData } from '../types';

export const processFile = async (file: File): Promise<ResumeData> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (event) => {
      const content = event.target?.result as string;
      
      // Simulate text extraction from PDF/DOCX
      const mockContent = `
        John Doe
        Software Engineer
        john.doe@email.com | (555) 123-4567 | LinkedIn: linkedin.com/in/johndoe
        
        PROFESSIONAL SUMMARY
        Experienced software engineer with 5+ years of experience in full-stack development.
        Proficient in JavaScript, React, Node.js, and cloud technologies.
        
        WORK EXPERIENCE
        Senior Software Engineer | TechCorp Inc. | 2021 - Present
        • Developed and maintained web applications using React and Node.js
        • Led a team of 3 developers on multiple projects
        • Improved application performance by 40% through code optimization
        
        Software Engineer | StartupXYZ | 2019 - 2021
        • Built responsive web applications using modern JavaScript frameworks
        • Collaborated with design and product teams to deliver user-centric solutions
        • Implemented automated testing reducing bugs by 30%
        
        SKILLS
        Programming Languages: JavaScript, TypeScript, Python, Java
        Frontend: React, Vue.js, HTML5, CSS3, Tailwind CSS
        Backend: Node.js, Express.js, Django, Spring Boot
        Databases: MongoDB, PostgreSQL, MySQL, Redis
        Tools: Git, Docker, AWS, Jenkins, Jira
        
        EDUCATION
        Bachelor of Science in Computer Science
        University of Technology | 2015 - 2019
        GPA: 3.8/4.0
        
        CERTIFICATIONS
        • AWS Certified Developer Associate
        • Google Cloud Professional Developer
        
        ACHIEVEMENTS
        • Employee of the Month (3 times)
        • Led successful migration to microservices architecture
        • Published technical blog posts with 10k+ views
      `;
      
      resolve({
        id: Date.now().toString(),
        filename: file.name,
        content: mockContent,
        uploadedAt: new Date(),
      });
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    reader.readAsText(file);
  });
};

export const validateFile = (file: File): string | null => {
  const maxSize = 5 * 1024 * 1024; // 5MB
  const allowedTypes = [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/msword',
    'text/plain',
  ];

  if (file.size > maxSize) {
    return 'File size must be less than 5MB';
  }

  if (!allowedTypes.includes(file.type)) {
    return 'Please upload a PDF, DOCX, DOC, or TXT file';
  }

  return null;
};