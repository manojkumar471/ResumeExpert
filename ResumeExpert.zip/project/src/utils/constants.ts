export const INDUSTRIES = [
  { value: 'tech', label: 'Technology', icon: '💻' },
  { value: 'finance', label: 'Finance & Banking', icon: '💰' },
  { value: 'healthcare', label: 'Healthcare', icon: '🏥' },
  { value: 'marketing', label: 'Marketing & Sales', icon: '📈' },
  { value: 'education', label: 'Education', icon: '🎓' },
  { value: 'other', label: 'Other', icon: '🔧' },
] as const;

export const CAREER_LEVELS = [
  { value: 'fresher', label: 'Fresh Graduate', icon: '🌱' },
  { value: 'junior', label: 'Junior (1-3 years)', icon: '📊' },
  { value: 'mid', label: 'Mid-Level (3-7 years)', icon: '🚀' },
  { value: 'senior', label: 'Senior (7+ years)', icon: '⭐' },
  { value: 'executive', label: 'Executive/C-Suite', icon: '👔' },
] as const;

export const SCORE_COLORS = {
  excellent: 'text-green-400 bg-green-400/20',
  good: 'text-cyan-400 bg-cyan-400/20',
  average: 'text-yellow-400 bg-yellow-400/20',
  poor: 'text-red-400 bg-red-400/20',
} as const;

export const SUGGESTION_TYPES = {
  improvement: { color: 'border-l-yellow-400 bg-yellow-400/10', icon: '⚡' },
  addition: { color: 'border-l-green-400 bg-green-400/10', icon: '➕' },
  warning: { color: 'border-l-red-400 bg-red-400/10', icon: '⚠️' },
} as const;