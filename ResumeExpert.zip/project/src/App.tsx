import React from 'react';
import { motion } from 'framer-motion';
import { AppProvider, useAppContext } from './context/AppContext';
import Header from './components/Header';
import UploadSection from './components/UploadSection';
import JobDescriptionInput from './components/JobDescriptionInput';
import PreferencesSection from './components/PreferencesSection';
import AnalysisButton from './components/AnalysisButton';
import ScoreDisplay from './components/ScoreDisplay';
import SuggestionsPanel from './components/SuggestionsPanel';
import HeatmapVisualization from './components/HeatmapVisualization';
import CoverLetterGenerator from './components/CoverLetterGenerator';
import AICoach from './components/AICoach';
import ChatBot from './components/ChatBot';

const AppContent: React.FC = () => {
  const { state, dispatch } = useAppContext();

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      state.isDarkMode ? 'bg-slate-900' : 'bg-gray-50'
    }`}>
      <Header />
      
      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="flex justify-center mb-8">
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-2 flex space-x-2">
            <motion.button
              onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'analyze' })}
              className={`px-6 py-3 rounded-lg font-medium transition-all ${
                state.activeTab === 'analyze'
                  ? 'bg-cyan-600 text-white shadow-lg'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Resume Analysis
            </motion.button>
            <motion.button
              onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'cover-letter' })}
              className={`px-6 py-3 rounded-lg font-medium transition-all ${
                state.activeTab === 'cover-letter'
                  ? 'bg-purple-600 text-white shadow-lg'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Cover Letter Generator
            </motion.button>
            <motion.button
              onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'ai-coach' })}
              className={`px-6 py-3 rounded-lg font-medium transition-all ${
                state.activeTab === 'ai-coach'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              AI Career Coach
            </motion.button>
          </div>
        </div>
      </div>
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
        {state.activeTab === 'analyze' ? (
          // Resume Analysis Tab
          !state.analysisResult ? (
            // Upload and Configuration Phase
            <div className="space-y-8">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center mb-12"
              >
                <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                  AI-Powered Resume Analysis
                </h1>
                <p className="text-xl text-slate-300 max-w-3xl mx-auto">
                  Get instant feedback, ATS optimization, and personalized suggestions 
                  to make your resume stand out in today's competitive job market.
                </p>
              </motion.div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <UploadSection />
                  <PreferencesSection />
                </div>
                <div>
                  <JobDescriptionInput />
                </div>
              </div>

              <AnalysisButton />
            </div>
          ) : (
            // Analysis Results Phase
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-8"
            >
              <div className="text-center">
                <h1 className="text-3xl font-bold text-white mb-2">Analysis Complete!</h1>
                <p className="text-slate-300">Here's your comprehensive resume analysis</p>
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
                <div className="xl:col-span-1">
                  <ScoreDisplay result={state.analysisResult} />
                </div>
                
                <div className="xl:col-span-2 space-y-8">
                  <SuggestionsPanel result={state.analysisResult} />
                  {state.jobDescription && (
                    <HeatmapVisualization result={state.analysisResult} />
                  )}
                </div>
              </div>

              <div className="text-center">
                <motion.button
                  onClick={() => window.location.reload()}
                  className="px-6 py-3 bg-slate-700 hover:bg-slate-600 rounded-lg text-white font-medium transition-colors"
                  whileHover={{ scale: 1.05 }}
                >
                  Analyze Another Resume
                </motion.button>
              </div>
            </motion.div>
          )
        ) : state.activeTab === 'cover-letter' ? (
          // Cover Letter Generator Tab
          <CoverLetterGenerator />
        ) : (
          // AI Career Coach Tab
          <AICoach />
        )}
      </main>

      <ChatBot />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;