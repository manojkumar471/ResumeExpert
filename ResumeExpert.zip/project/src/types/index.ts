export interface ResumeData {
  id: string;
  filename: string;
  content: string;
  uploadedAt: Date;
}

export interface JobDescription {
  title: string;
  company: string;
  content: string;
  industry: string;
}

export interface AnalysisResult {
  overallScore: number;
  breakdown: ScoreBreakdown;
  suggestions: Suggestion[];
  keywords: KeywordAnalysis;
  atsCompatibility: number;
  heatmapData: HeatmapData[];
}

export interface ScoreBreakdown {
  skills: number;
  experience: number;
  education: number;
  achievements: number;
  language: number;
  layout: number;
  atsOptimization: number;
}

export interface Suggestion {
  id: string;
  type: 'improvement' | 'addition' | 'warning';
  section: string;
  message: string;
  priority: 'high' | 'medium' | 'low';
}

export interface KeywordAnalysis {
  matched: string[];
  missing: string[];
  relevanceScore: number;
}

export interface HeatmapData {
  section: string;
  similarity: number;
  keywords: string[];
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

export interface CoverLetterRequest {
  resumeContent: string;
  jobTitle: string;
  jobDescription: string;
  companyName: string;
  tone: 'friendly' | 'formal' | 'confident' | 'assertive';
  candidateLocation?: string;
  yearsExperience?: string;
  specificAchievements?: string;
  additionalNotes?: string;
}

export interface CoverLetterResult {
  id: string;
  content: string;
  generatedAt: Date;
  jobTitle: string;
  companyName: string;
  tone: string;
}

export interface AICoachAnalysis {
  id: string;
  overallAssessment: string;
  strengths: string[];
  weaknesses: string[];
  detailedFeedback: {
    section: string;
    feedback: string;
    suggestions: string[];
    priority: 'high' | 'medium' | 'low';
  }[];
  careerAdvice: string[];
  industryInsights: string[];
  nextSteps: string[];
  confidenceScore: number;
  marketReadiness: number;
  generatedAt: Date;
}

export interface CoachingSession {
  id: string;
  type: 'resume-review' | 'career-guidance' | 'interview-prep' | 'skill-assessment';
  messages: ChatMessage[];
  analysis?: AICoachAnalysis;
  startedAt: Date;
  status: 'active' | 'completed';
}

export type Industry = 'tech' | 'finance' | 'healthcare' | 'marketing' | 'education' | 'other';
export type CareerLevel = 'fresher' | 'junior' | 'mid' | 'senior' | 'executive';

export interface UserPreferences {
  industry: Industry;
  careerLevel: CareerLevel;
  darkMode: boolean;
}