import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { ResumeData, JobDescription, AnalysisResult, UserPreferences, ChatMessage, CoverLetterResult, AICoachAnalysis, CoachingSession } from '../types';

interface AppState {
  resume: ResumeData | null;
  jobDescription: JobDescription | null;
  analysisResult: AnalysisResult | null;
  preferences: UserPreferences;
  chatMessages: ChatMessage[];
  coverLetters: CoverLetterResult[];
  coachAnalysis: AICoachAnalysis | null;
  coachingSessions: CoachingSession[];
  activeCoachingSession: string | null;
  isAnalyzing: boolean;
  isGeneratingCoverLetter: boolean;
  isCoachAnalyzing: boolean;
  isDarkMode: boolean;
  activeTab: 'analyze' | 'cover-letter' | 'ai-coach';
}

type AppAction =
  | { type: 'SET_RESUME'; payload: ResumeData | null }
  | { type: 'SET_JOB_DESCRIPTION'; payload: JobDescription | null }
  | { type: 'SET_ANALYSIS_RESULT'; payload: AnalysisResult }
  | { type: 'SET_PREFERENCES'; payload: Partial<UserPreferences> }
  | { type: 'ADD_CHAT_MESSAGE'; payload: ChatMessage }
  | { type: 'ADD_COVER_LETTER'; payload: CoverLetterResult }
  | { type: 'SET_COACH_ANALYSIS'; payload: AICoachAnalysis }
  | { type: 'ADD_COACHING_SESSION'; payload: CoachingSession }
  | { type: 'UPDATE_COACHING_SESSION'; payload: { id: string; messages: ChatMessage[] } }
  | { type: 'SET_ACTIVE_COACHING_SESSION'; payload: string | null }
  | { type: 'SET_ANALYZING'; payload: boolean }
  | { type: 'SET_GENERATING_COVER_LETTER'; payload: boolean }
  | { type: 'SET_COACH_ANALYZING'; payload: boolean }
  | { type: 'SET_ACTIVE_TAB'; payload: 'analyze' | 'cover-letter' | 'ai-coach' }
  | { type: 'TOGGLE_DARK_MODE' }
  | { type: 'CLEAR_ANALYSIS' };

const initialState: AppState = {
  resume: null,
  jobDescription: null,
  analysisResult: null,
  preferences: {
    industry: 'tech',
    careerLevel: 'mid',
    darkMode: true,
  },
  chatMessages: [],
  coverLetters: [],
  coachAnalysis: null,
  coachingSessions: [],
  activeCoachingSession: null,
  isAnalyzing: false,
  isGeneratingCoverLetter: false,
  isCoachAnalyzing: false,
  isDarkMode: true,
  activeTab: 'analyze',
};

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'SET_RESUME':
      return { ...state, resume: action.payload };
    case 'SET_JOB_DESCRIPTION':
      return { ...state, jobDescription: action.payload };
    case 'SET_ANALYSIS_RESULT':
      return { ...state, analysisResult: action.payload, isAnalyzing: false };
    case 'SET_PREFERENCES':
      return { ...state, preferences: { ...state.preferences, ...action.payload } };
    case 'ADD_CHAT_MESSAGE':
      return { ...state, chatMessages: [...state.chatMessages, action.payload] };
    case 'ADD_COVER_LETTER':
      return { ...state, coverLetters: [action.payload, ...state.coverLetters], isGeneratingCoverLetter: false };
    case 'SET_COACH_ANALYSIS':
      return { ...state, coachAnalysis: action.payload, isCoachAnalyzing: false };
    case 'ADD_COACHING_SESSION':
      return { 
        ...state, 
        coachingSessions: [action.payload, ...state.coachingSessions],
        activeCoachingSession: action.payload.id
      };
    case 'UPDATE_COACHING_SESSION':
      return {
        ...state,
        coachingSessions: state.coachingSessions.map(session =>
          session.id === action.payload.id
            ? { ...session, messages: action.payload.messages }
            : session
        )
      };
    case 'SET_ACTIVE_COACHING_SESSION':
      return { ...state, activeCoachingSession: action.payload };
    case 'SET_ANALYZING':
      return { ...state, isAnalyzing: action.payload };
    case 'SET_GENERATING_COVER_LETTER':
      return { ...state, isGeneratingCoverLetter: action.payload };
    case 'SET_COACH_ANALYZING':
      return { ...state, isCoachAnalyzing: action.payload };
    case 'SET_ACTIVE_TAB':
      return { ...state, activeTab: action.payload };
    case 'TOGGLE_DARK_MODE':
      return { ...state, isDarkMode: !state.isDarkMode };
    case 'CLEAR_ANALYSIS':
      return { ...state, analysisResult: null, chatMessages: [] };
    default:
      return state;
  }
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
};